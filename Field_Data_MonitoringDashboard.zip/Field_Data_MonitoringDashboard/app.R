# Rwanda ECD Dashboard - Complete Application with KoboToolbox Integration
# Using your provided color palette and questionnaire structure

library(shiny)
library(shinydashboard)
library(shinydashboardPlus)
library(plotly)
library(leaflet)
library(DT)
library(dplyr)
library(tidyr)
library(ggplot2)
library(fresh)
library(httr)
library(jsonlite)
library(lubridate)

# Your color palette
colors <- c("#034742", "#2ca02c", "#092CA0", "#431d85", "#570631", 
            "#9e086f", "#87CEEB", "#add8e6", "#FFA500", "#1f77b4")

# Custom theme using fresh package
mytheme <- create_theme(
  adminlte_color(
    light_blue = colors[1],
    blue = colors[3],
    green = colors[2],
    red = colors[5],
    yellow = colors[9],
    navy = colors[4],
    teal = colors[7],
    olive = colors[10],
    lime = colors[6],
    orange = colors[9],
    fuchsia = colors[6],
    maroon = colors[5],
    black = "#222d32",
    gray_lte = "#d2d6de"
  ),
  adminlte_sidebar(
    width = "300px",
    dark_bg = "#222d32",
    dark_hover_bg = colors[1],
    dark_color = "#b8c7ce"
  ),
  adminlte_global(
    content_bg = "#f9f9f9",
    box_bg = "#ffffff",
    info_box_bg = colors[7]
  )
)

# KoboToolbox API connection function
kobo_api <- function(username, password, form_id = "rwanda_ecd_dashboard_v1") {
  url <- paste0("https://kc.kobotoolbox.org/api/v1/data/", form_id, ".json")
  
  tryCatch({
    # Authenticate and get data
    response <- GET(url, authenticate(username, password), timeout(30))
    
    if (status_code(response) == 200) {
      data <- fromJSON(content(response, "text"))
      
      # Transform nested JSON to flat data frame
      if (length(data) > 0) {
        # Extract main data
        main_data <- data
        
        # Convert to data frame and clean column names
        df <- as.data.frame(main_data)
        
        # Remove system columns
        df <- df %>%
          select(-starts_with("_")) %>%
          mutate(across(where(is.character), ~na_if(., "")))
        
        # Convert date fields
        if ("date_visit" %in% names(df)) {
          df$date_visit <- ymd_hms(df$date_visit) %>% as.Date()
        }
        
        # Convert numeric fields
        numeric_fields <- c("year_established", "num_classrooms", "total_capacity", 
                            "current_enrollment", "num_caregivers", "num_support_staff",
                            "num_children_0_2", "num_children_3_4", "num_children_5",
                            "delayed_access", "dropouts", "travel_distance", 
                            "hours_learning")
        
        for (field in numeric_fields) {
          if (field %in% names(df)) {
            df[[field]] <- as.numeric(df[[field]])
          }
        }
        
        # Calculate derived fields
        if ("current_enrollment" %in% names(df) & "num_caregivers" %in% names(df)) {
          df$caregiver_ratio <- ifelse(df$num_caregivers > 0, 
                                       round(df$current_enrollment / df$num_caregivers, 1),
                                       0)
        }
        
        if ("current_enrollment" %in% names(df) & "total_capacity" %in% names(df)) {
          df$capacity_utilization <- ifelse(df$total_capacity > 0,
                                            round(df$current_enrollment / df$total_capacity * 100, 1),
                                            0)
        }
        
        # Calculate quality score
        quality_fields <- c("training_received", "water_sanitation", "learning_materials",
                            "nutrition_program", "parent_involvement")
        
        df$quality_score <- rowSums(df[, quality_fields] == "yes", na.rm = TRUE)
        
        return(df)
      } else {
        return(data.frame())  # Return empty data frame if no data
      }
    } else {
      showNotification(paste("API Error:", status_code(response)), type = "error")
      return(data.frame())
    }
  }, error = function(e) {
    showNotification(paste("Connection Error:", e$message), type = "error")
    return(data.frame())
  })
}

# UI Definition
ui <- dashboardPage(
  skin = "blue",
  freshTheme = mytheme,
  
  # Header
  dashboardHeader(
    title = tags$div(
      tags$img(src = "https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/Flag_of_Rwanda.svg/320px-Flag_of_Rwanda.svg.png", 
               height = "30px", style = "margin-right: 10px;"),
      tags$span("RWANDA ECD MONITORING DASHBOARD", style = "font-weight: bold; color: white;")
    ),
    titleWidth = 350,
    tags$li(
      class = "dropdown",
      tags$a(href = "#", icon("sync"), "Last Updated: ", textOutput("update_time", inline = TRUE))
    )
  ),
  
  # Sidebar
  dashboardSidebar(
    width = 350,
    sidebarMenu(
      id = "sidebar",
      menuItem("Dashboard Overview", tabName = "overview", icon = icon("dashboard")),
      menuItem("Access & Enrollment", tabName = "access", icon = icon("child")),
      menuItem("Quality Indicators", tabName = "quality", icon = icon("star")),
      menuItem("Geographic Distribution", tabName = "map", icon = icon("map")),
      menuItem("Center Details", tabName = "details", icon = icon("building")),
      menuItem("Data Management", tabName = "data", icon = icon("database")),
      menuItem("Reports & Analytics", tabName = "reports", icon = icon("chart-bar")),
      
      hr(),
      
      # KoboToolbox Connection
      div(style = "padding: 15px;",
          h4("KOBOTOOLBOX CONNECTION", style = "color: #ffffff; margin-bottom: 15px;"),
          
          textInput("kobo_username", "Username:", 
                    placeholder = "Enter KoboToolbox username"),
          
          passwordInput("kobo_password", "Password:",
                        placeholder = "Enter password"),
          
          textInput("kobo_form_id", "Form ID:", 
                    value = "rwanda_ecd_dashboard_v1",
                    placeholder = "rwanda_ecd_dashboard_v1"),
          
          actionButton("connect_kobo", "Connect to KoboToolbox", 
                       icon = icon("plug"),
                       class = "btn-primary", 
                       style = paste0("background-color:", colors[2], "; color: white; width: 100%;")),
          
          br(), br(),
          
          h4("DATA FILTERS", style = "color: #ffffff; margin-bottom: 15px;"),
          
          selectInput("district_filter", "District:",
                      choices = "All",
                      selected = "All"),
          
          selectInput("center_type_filter", "Center Type:",
                      choices = "All",
                      selected = "All"),
          
          sliderInput("enrollment_filter", "Enrollment Range:",
                      min = 0, max = 500, value = c(0, 500)),
          
          dateRangeInput("date_filter", "Date Range:",
                         start = Sys.Date() - 30,
                         end = Sys.Date()),
          
          actionButton("apply_filters", "Apply Filters", 
                       class = "btn-primary", 
                       style = paste0("background-color:", colors[3], "; color: white; width: 100%;")),
          
          actionButton("reset_filters", "Reset", 
                       style = "width: 100%; margin-top: 10px;")
      )
    )
  ),
  
  # Body
  dashboardBody(
    tags$head(
      tags$style(HTML("
        /* Custom styling */
        .small-box {border-radius: 10px;}
        .info-box {border-radius: 8px;}
        .box {border-radius: 8px; border-top: 3px solid;}
        
        /* Color coding for metrics */
        .high-quality {color: #2ca02c; font-weight: bold;}
        .medium-quality {color: #FFA500; font-weight: bold;}
        .low-quality {color: #9e086f; font-weight: bold;}
        
        /* Map styling */
        .leaflet-container {border-radius: 8px;}
        
        /* Card headers */
        .box-header {background-color: #f8f9fa;}
        
        /* Connection status */
        .connection-good {color: #2ca02c;}
        .connection-bad {color: #9e086f;}
        
        /* Tab styling */
        .nav-tabs-custom .nav-tabs li.active {border-top-color: #034742;}
      "))
    ),
    
    tabItems(
      # Tab 1: Overview
      tabItem(
        tabName = "overview",
        fluidRow(
          # Connection Status
          box(
            title = "Data Source Status",
            status = "info",
            solidHeader = TRUE,
            width = 12,
            collapsible = TRUE,
            collapsed = TRUE,
            div(
              style = "padding: 15px;",
              uiOutput("connection_status"),
              br(),
              actionButton("refresh_data", "Refresh Data", 
                           icon = icon("sync"),
                           style = paste0("background-color:", colors[2], "; color: white;")),
              actionButton("load_sample", "Load Sample Data", 
                           icon = icon("file-import"),
                           style = paste0("background-color:", colors[9], "; color: white; margin-left: 10px;"))
            )
          )
        ),
        
        fluidRow(
          # Key Metrics
          valueBoxOutput("total_centers", width = 3),
          valueBoxOutput("total_enrollment", width = 3),
          valueBoxOutput("avg_caregiver_ratio", width = 3),
          valueBoxOutput("quality_score", width = 3)
        ),
        
        fluidRow(
          # Charts
          box(
            title = "Enrollment by Center Type", 
            status = "primary", 
            solidHeader = TRUE,
            width = 6,
            plotlyOutput("enrollment_by_type", height = 300)
          ),
          
          box(
            title = "Services Distribution", 
            status = "success", 
            solidHeader = TRUE,
            width = 6,
            plotlyOutput("services_chart", height = 300)
          )
        ),
        
        fluidRow(
          box(
            title = "Recent Survey Activity", 
            status = "info", 
            solidHeader = TRUE,
            width = 12,
            DTOutput("recent_surveys")
          )
        )
      ),
      
      # Tab 2: Access & Enrollment
      tabItem(
        tabName = "access",
        fluidRow(
          box(
            title = "Enrollment Trends by Age Group",
            status = "primary",
            solidHeader = TRUE,
            width = 8,
            plotlyOutput("age_distribution", height = 400)
          ),
          
          box(
            title = "Access Metrics",
            status = "info",
            solidHeader = TRUE,
            width = 4,
            div(style = "padding: 20px;",
                h4("Average Travel Distance:", style = "color: #034742;"),
                h2(textOutput("avg_travel_distance"), style = "color: #092CA0;"),
                br(),
                h4("Delayed Access Rate:", style = "color: #034742;"),
                h2(textOutput("delayed_access_rate"), style = "color: #9e086f;"),
                br(),
                h4("Dropout Rate (6 months):", style = "color: #034742;"),
                h2(textOutput("dropout_rate"), style = "color: #570631;"),
                br(),
                h4("Capacity Utilization:", style = "color: #034742;"),
                h2(textOutput("capacity_utilization"), style = "color: #2ca02c;")
            )
          )
        ),
        
        fluidRow(
          box(
            title = "Capacity vs. Enrollment",
            status = "success",
            solidHeader = TRUE,
            width = 12,
            plotlyOutput("capacity_chart", height = 300)
          )
        )
      ),
      
      # Tab 3: Quality Indicators
      tabItem(
        tabName = "quality",
        fluidRow(
          box(
            title = "Quality Indicators Dashboard",
            status = "primary",
            solidHeader = TRUE,
            width = 12,
            fluidRow(
              column(3, 
                     div(class = "small-box", style = paste0("background-color:", colors[2], "; padding: 20px; border-radius: 8px;"),
                         h4("Training Received", style = "color: white;"),
                         h2(textOutput("training_rate"), style = "color: white;"),
                         h5("of caregivers", style = "color: white;")
                     )
              ),
              column(3,
                     div(class = "small-box", style = paste0("background-color:", colors[3], "; padding: 20px; border-radius: 8px;"),
                         h4("Water & Sanitation", style = "color: white;"),
                         h2(textOutput("water_sanitation_rate"), style = "color: white;"),
                         h5("of centers", style = "color: white;")
                     )
              ),
              column(3,
                     div(class = "small-box", style = paste0("background-color:", colors[6], "; padding: 20px; border-radius: 8px;"),
                         h4("Learning Materials", style = "color: white;"),
                         h2(textOutput("materials_rate"), style = "color: white;"),
                         h5("of centers", style = "color: white;")
                     )
              ),
              column(3,
                     div(class = "small-box", style = paste0("background-color:", colors[9], "; padding: 20px; border-radius: 8px;"),
                         h4("Parent Involvement", style = "color: white;"),
                         h2(textOutput("parent_involvement_rate"), style = "color: white;"),
                         h5("of centers", style = "color: white;")
                     )
              )
            ),
            br(),
            plotlyOutput("quality_radar", height = 400)
          )
        )
      ),
      
      # Tab 4: Map
      tabItem(
        tabName = "map",
        fluidRow(
          box(
            title = "ECD Centers Geographic Distribution",
            status = "primary",
            solidHeader = TRUE,
            width = 12,
            leafletOutput("ecd_map", height = 600)
          )
        ),
        
        fluidRow(
          box(
            title = "District Summary",
            status = "info",
            solidHeader = TRUE,
            width = 12,
            DTOutput("district_summary")
          )
        )
      ),
      
      # Tab 5: Center Details
      tabItem(
        tabName = "details",
        fluidRow(
          box(
            title = "ECD Center Directory",
            status = "primary",
            solidHeader = TRUE,
            width = 12,
            DTOutput("center_directory")
          )
        ),
        
        fluidRow(
          box(
            title = "Center Detailed View",
            status = "success",
            solidHeader = TRUE,
            width = 12,
            uiOutput("center_details")
          )
        )
      ),
      
      # Tab 6: Data Management
      tabItem(
        tabName = "data",
        fluidRow(
          box(
            title = "Data Import & Export",
            status = "primary",
            solidHeader = TRUE,
            width = 6,
            div(style = "padding: 20px;",
                h4("Export Current Data"),
                downloadButton("export_csv", "Export as CSV",
                               style = paste0("background-color:", colors[2], "; color: white;")),
                downloadButton("export_excel", "Export as Excel",
                               style = paste0("background-color:", colors[3], "; color: white; margin-left: 10px;")),
                br(), br(),
                h4("Import External Data"),
                fileInput("import_file", "Choose CSV/Excel file",
                          accept = c(".csv", ".xlsx", ".xls")),
                actionButton("process_import", "Process Imported Data",
                             style = paste0("background-color:", colors[6], "; color: white;"))
            )
          ),
          
          box(
            title = "Data Quality Check",
            status = "info",
            solidHeader = TRUE,
            width = 6,
            div(style = "padding: 20px;",
                h4("Data Completeness Report"),
                tableOutput("data_quality"),
                br(),
                actionButton("run_quality_check", "Run Quality Check",
                             icon = icon("search"),
                             style = paste0("background-color:", colors[9], "; color: white; width: 100%;"))
            )
          )
        ),
        
        fluidRow(
          box(
            title = "Raw Data Preview",
            status = "warning",
            solidHeader = TRUE,
            width = 12,
            DTOutput("raw_data_preview")
          )
        )
      ),
      
      # Tab 7: Reports
      tabItem(
        tabName = "reports",
        fluidRow(
          box(
            title = "Generate Reports",
            status = "primary",
            solidHeader = TRUE,
            width = 4,
            div(style = "padding: 20px;",
                selectInput("report_type", "Report Type:",
                            choices = c("Access Analysis", "Quality Assessment", 
                                        "Enrollment Trends", "Comprehensive Report")),
                selectInput("report_format", "Format:",
                            choices = c("PDF", "HTML", "Word")),
                textInput("report_title", "Report Title:", 
                          value = "ECD Monitoring Report"),
                br(),
                downloadButton("download_report", "Generate Report",
                               style = paste0("background-color:", colors[2], "; color: white; width: 100%;"))
            )
          ),
          
          box(
            title = "Predictive Analytics",
            status = "info",
            solidHeader = TRUE,
            width = 8,
            plotlyOutput("predictive_chart", height = 400),
            br(),
            sliderInput("forecast_months", "Forecast Period (Months):",
                        min = 3, max = 24, value = 12, step = 3)
          )
        )
      )
    )
  )
)

# Server Logic
server <- function(input, output, session) {
  
  # Reactive values for data storage
  rv <- reactiveValues(
    ecd_data = data.frame(),
    connection_status = "Disconnected",
    last_update = Sys.time()
  )
  
  # Function to load sample data
  load_sample_data <- function() {
    set.seed(123)
    n <- 50
    
    sample_data <- data.frame(
      center_name = paste("ECD Center", 1:n),
      center_type = sample(c("Community-based", "Public", "Private", "Faith-based"), n, replace = TRUE),
      location_district = sample(c("Gasabo", "Kicukiro", "Nyarugenge", "Burera", "Gakenke"), n, replace = TRUE),
      gps_location__Latitude = -1.9 + runif(n, -0.1, 0.1),
      gps_location__Longitude = 30.1 + runif(n, -0.1, 0.1),
      year_established = sample(2010:2023, n, replace = TRUE),
      num_classrooms = sample(1:10, n, replace = TRUE),
      total_capacity = sample(20:200, n, replace = TRUE),
      current_enrollment = sample(15:180, n, replace = TRUE),
      num_caregivers = sample(2:15, n, replace = TRUE),
      num_support_staff = sample(1:8, n, replace = TRUE),
      num_children_0_2 = sample(0:30, n, replace = TRUE),
      num_children_3_4 = sample(5:80, n, replace = TRUE),
      num_children_5 = sample(5:70, n, replace = TRUE),
      travel_distance = runif(n, 0.5, 10),
      training_received = sample(c("yes", "no"), n, replace = TRUE, prob = c(0.7, 0.3)),
      water_sanitation = sample(c("yes", "no"), n, replace = TRUE, prob = c(0.8, 0.2)),
      learning_materials = sample(c("yes", "no"), n, replace = TRUE, prob = c(0.65, 0.35)),
      nutrition_program = sample(c("yes", "no"), n, replace = TRUE, prob = c(0.6, 0.4)),
      parent_involvement = sample(c("yes", "no"), n, replace = TRUE, prob = c(0.75, 0.25)),
      date_visit = sample(seq(Sys.Date() - 60, Sys.Date(), by = "day"), n, replace = TRUE),
      surveyor_name = sample(c("Team A", "Team B", "Team C"), n, replace = TRUE),
      stringsAsFactors = FALSE
    ) %>%
      mutate(
        caregiver_ratio = round(current_enrollment / num_caregivers, 1),
        capacity_utilization = round(current_enrollment / total_capacity * 100, 1),
        quality_score = (training_received == "yes") + 
          (water_sanitation == "yes") + 
          (learning_materials == "yes") +
          (parent_involvement == "yes")
      )
    
    return(sample_data)
  }
  
  # Initialize with sample data
  observe({
    rv$ecd_data <- load_sample_data()
    rv$last_update <- Sys.time()
  })
  
  # Connect to KoboToolbox
  observeEvent(input$connect_kobo, {
    if (nchar(input$kobo_username) > 0 && nchar(input$kobo_password) > 0) {
      showNotification("Connecting to KoboToolbox...", type = "info")
      
      # Call API function
      kobo_data <- kobo_api(input$kobo_username, input$kobo_password, input$kobo_form_id)
      
      if (nrow(kobo_data) > 0) {
        rv$ecd_data <- kobo_data
        rv$connection_status <- "Connected"
        rv$last_update <- Sys.time()
        
        # Update filter choices based on new data
        updateSelectInput(session, "district_filter",
                          choices = c("All", unique(kobo_data$location_district)))
        updateSelectInput(session, "center_type_filter",
                          choices = c("All", unique(kobo_data$center_type)))
        
        showNotification(paste("Successfully loaded", nrow(kobo_data), "records from KoboToolbox!"), 
                         type = "success", duration = 5)
      } else {
        showNotification("No data received from KoboToolbox. Check credentials and form ID.", 
                         type = "warning", duration = 5)
      }
    } else {
      showNotification("Please enter KoboToolbox credentials", type = "error")
    }
  })
  
  # Load sample data
  observeEvent(input$load_sample, {
    rv$ecd_data <- load_sample_data()
    rv$connection_status <- "Sample Data"
    rv$last_update <- Sys.time()
    
    showNotification("Loaded sample data successfully!", type = "info")
  })
  
  # Refresh data
  observeEvent(input$refresh_data, {
    if (rv$connection_status == "Connected" && 
        nchar(input$kobo_username) > 0 && 
        nchar(input$kobo_password) > 0) {
      
      kobo_data <- kobo_api(input$kobo_username, input$kobo_password, input$kobo_form_id)
      
      if (nrow(kobo_data) > 0) {
        rv$ecd_data <- kobo_data
        rv$last_update <- Sys.time()
        showNotification("Data refreshed from KoboToolbox!", type = "success")
      }
    } else {
      showNotification("Please connect to KoboToolbox first", type = "warning")
    }
  })
  
  # Filtered data based on user inputs
  filtered_data <- reactive({
    data <- rv$ecd_data
    
    if (nrow(data) == 0) {
      return(data.frame())
    }
    
    # Apply filters
    if (input$district_filter != "All" && "location_district" %in% names(data)) {
      data <- data %>% filter(location_district == input$district_filter)
    }
    
    if (input$center_type_filter != "All" && "center_type" %in% names(data)) {
      data <- data %>% filter(center_type == input$center_type_filter)
    }
    
    if ("current_enrollment" %in% names(data)) {
      data <- data %>%
        filter(current_enrollment >= input$enrollment_filter[1] &
                 current_enrollment <= input$enrollment_filter[2])
    }
    
    if ("date_visit" %in% names(data)) {
      data <- data %>%
        filter(date_visit >= input$date_filter[1] &
                 date_visit <= input$date_filter[2])
    }
    
    return(data)
  })
  
  # Connection status output
  output$connection_status <- renderUI({
    status_class <- ifelse(rv$connection_status == "Connected", 
                           "connection-good", "connection-bad")
    
    div(
      p(strong("Status: "), span(rv$connection_status, class = status_class)),
      p(strong("Records loaded: "), nrow(rv$ecd_data)),
      p(strong("Last update: "), format(rv$last_update, "%Y-%m-%d %H:%M:%S"))
    )
  })
  
  # Value boxes
  output$total_centers <- renderValueBox({
    data <- filtered_data()
    valueBox(
      value = nrow(data),
      subtitle = "Total ECD Centers",
      icon = icon("building"),
      color = "blue"
    )
  })
  
  output$total_enrollment <- renderValueBox({
    data <- filtered_data()
    total <- ifelse("current_enrollment" %in% names(data),
                    sum(data$current_enrollment, na.rm = TRUE),
                    0)
    valueBox(
      value = format(total, big.mark = ","),
      subtitle = "Total Children Enrolled",
      icon = icon("child"),
      color = "green"
    )
  })
  
  output$avg_caregiver_ratio <- renderValueBox({
    data <- filtered_data()
    if ("caregiver_ratio" %in% names(data) && nrow(data) > 0) {
      ratio <- mean(data$caregiver_ratio, na.rm = TRUE)
    } else {
      ratio <- 0
    }
    
    valueBox(
      value = round(ratio, 1),
      subtitle = "Avg Caregiver:Child Ratio",
      icon = icon("users"),
      color = ifelse(ratio > 10, "red", ifelse(ratio > 7, "yellow", "green"))
    )
  })
  
  output$quality_score <- renderValueBox({
    data <- filtered_data()
    if ("quality_score" %in% names(data) && nrow(data) > 0) {
      avg_score <- mean(data$quality_score, na.rm = TRUE)
    } else {
      avg_score <- 0
    }
    
    valueBox(
      value = round(avg_score, 1),
      subtitle = "Avg Quality Score (out of 4)",
      icon = icon("star"),
      color = ifelse(avg_score >= 3, "green", ifelse(avg_score >= 2, "yellow", "red"))
    )
  })
  
  # Charts
  output$enrollment_by_type <- renderPlotly({
    data <- filtered_data()
    
    if (nrow(data) == 0 || !"center_type" %in% names(data)) {
      return(plotly_empty(type = "scatter") %>% 
               layout(title = "No data available"))
    }
    
    plot_data <- data %>%
      group_by(center_type) %>%
      summarize(total_enrollment = sum(current_enrollment, na.rm = TRUE))
    
    plot_ly(plot_data, 
            x = ~center_type, 
            y = ~total_enrollment,
            type = 'bar',
            marker = list(color = colors[1:length(unique(plot_data$center_type))])) %>%
      layout(title = "",
             xaxis = list(title = "Center Type"),
             yaxis = list(title = "Total Enrollment"),
             plot_bgcolor = '#f9f9f9',
             paper_bgcolor = '#f9f9f9')
  })
  
  output$services_chart <- renderPlotly({
    data <- filtered_data()
    
    if (nrow(data) == 0) {
      return(plotly_empty(type = "scatter") %>% 
               layout(title = "No data available"))
    }
    
    services_summary <- data.frame(
      Service = c("Training", "Water/Sanitation", "Materials", "Nutrition", "Parent Involvement"),
      Yes = c(sum(data$training_received == "yes", na.rm = TRUE),
              sum(data$water_sanitation == "yes", na.rm = TRUE),
              sum(data$learning_materials == "yes", na.rm = TRUE),
              sum(data$nutrition_program == "yes", na.rm = TRUE),
              sum(data$parent_involvement == "yes", na.rm = TRUE)),
      Total = nrow(data)
    ) %>%
      mutate(Percentage = round(Yes / Total * 100, 1))
    
    plot_ly(services_summary,
            x = ~Percentage,
            y = ~Service,
            type = 'bar',
            orientation = 'h',
            marker = list(color = colors[c(1,3,6,9,10)])) %>%
      layout(title = "",
             xaxis = list(title = "Percentage of Centers", ticksuffix = "%"),
             yaxis = list(title = ""),
             plot_bgcolor = '#f9f9f9',
             paper_bgcolor = '#f9f9f9')
  })
  
  output$age_distribution <- renderPlotly({
    data <- filtered_data()
    
    if (nrow(data) == 0) {
      return(plotly_empty(type = "scatter") %>% 
               layout(title = "No data available"))
    }
    
    age_data <- data %>%
      summarize(
        `0-2 years` = sum(num_children_0_2, na.rm = TRUE),
        `3-4 years` = sum(num_children_3_4, na.rm = TRUE),
        `5 years` = sum(num_children_5, na.rm = TRUE)
      ) %>%
      pivot_longer(cols = everything(), names_to = "Age Group", values_to = "Count")
    
    plot_ly(age_data,
            labels = ~`Age Group`,
            values = ~Count,
            type = 'pie',
            hole = 0.4,
            marker = list(colors = colors[c(1,3,6)]),
            textinfo = 'label+percent') %>%
      layout(title = "",
             plot_bgcolor = '#f9f9f9',
             paper_bgcolor = '#f9f9f9')
  })
  
  output$capacity_chart <- renderPlotly({
    data <- filtered_data() %>%
      arrange(desc(current_enrollment)) %>%
      head(15)
    
    if (nrow(data) == 0) {
      return(plotly_empty(type = "scatter") %>% 
               layout(title = "No data available"))
    }
    
    plot_ly(data) %>%
      add_trace(x = ~center_name,
                y = ~total_capacity,
                type = 'bar',
                name = 'Total Capacity',
                marker = list(color = colors[7])) %>%
      add_trace(x = ~center_name,
                y = ~current_enrollment,
                type = 'bar',
                name = 'Current Enrollment',
                marker = list(color = colors[2])) %>%
      layout(title = "",
             xaxis = list(title = "ECD Center", tickangle = -45),
             yaxis = list(title = "Number of Children"),
             barmode = 'group',
             plot_bgcolor = '#f9f9f9',
             paper_bgcolor = '#f9f9f9',
             legend = list(orientation = 'h'))
  })
  
  output$quality_radar <- renderPlotly({
    data <- filtered_data()
    
    if (nrow(data) == 0) {
      return(plotly_empty(type = "scatter") %>% 
               layout(title = "No data available"))
    }
    
    quality_metrics <- data.frame(
      rbind(
        c("Training", mean(data$training_received == "yes", na.rm = TRUE) * 100),
        c("Water/Sanitation", mean(data$water_sanitation == "yes", na.rm = TRUE) * 100),
        c("Learning Materials", mean(data$learning_materials == "yes", na.rm = TRUE) * 100),
        c("Nutrition Program", mean(data$nutrition_program == "yes", na.rm = TRUE) * 100),
        c("Parent Involvement", mean(data$parent_involvement == "yes", na.rm = TRUE) * 100)
      )
    )
    colnames(quality_metrics) <- c("Metric", "Value")
    quality_metrics$Value <- as.numeric(quality_metrics$Value)
    
    plot_ly(
      type = 'scatterpolar',
      mode = 'lines+markers',
      fill = 'toself'
    ) %>%
      add_trace(
        r = quality_metrics$Value,
        theta = quality_metrics$Metric,
        name = "Quality Metrics",
        fillcolor = paste0(colors[7], "80"),
        line = list(color = colors[3], width = 2),
        marker = list(size = 8, color = colors[3])
      ) %>%
      layout(
        polar = list(
          radialaxis = list(
            visible = TRUE,
            range = c(0,100),
            ticksuffix = "%"
          )
        ),
        showlegend = FALSE,
        plot_bgcolor = '#f9f9f9',
        paper_bgcolor = '#f9f9f9'
      )
  })
  
  # Map
  output$ecd_map <- renderLeaflet({
    data <- filtered_data()
    
    if (nrow(data) == 0 || !"gps_location__Longitude" %in% names(data)) {
      return(leaflet() %>% addTiles())
    }
    
    # Create color palette based on quality score
    if ("quality_score" %in% names(data)) {
      pal <- colorNumeric(
        palette = colors[c(2,9,5)],
        domain = data$quality_score
      )
    } else {
      pal <- colorFactor(colors[1], domain = 1)
    }
    
    leaflet(data) %>%
      addTiles() %>%
      addCircleMarkers(
        lng = ~gps_location__Longitude,
        lat = ~gps_location__Latitude,
        radius = ~sqrt(current_enrollment)/2 + 5,
        color = ~ifelse("quality_score" %in% names(data), pal(quality_score), colors[1]),
        fillOpacity = 0.7,
        stroke = TRUE,
        weight = 1,
        label = ~paste(center_name, "-", center_type),
        popup = ~paste(
          "<strong>", center_name, "</strong><br>",
          "Type: ", center_type, "<br>",
          ifelse("location_district" %in% names(data), paste("District: ", location_district, "<br>"), ""),
          "Enrollment: ", current_enrollment, "<br>",
          ifelse("caregiver_ratio" %in% names(data), paste("Caregiver Ratio: ", caregiver_ratio, "<br>"), ""),
          ifelse("quality_score" %in% names(data), paste("Quality Score: ", quality_score, "/4", "<br>"), "")
        )
      ) %>%
      addLegend(
        position = "bottomright",
        pal = pal,
        values = ~ifelse("quality_score" %in% names(data), quality_score, 1),
        title = "Quality Score",
        opacity = 0.8
      )
  })
  
  # Tables
  output$recent_surveys <- renderDT({
    data <- filtered_data()
    
    if (nrow(data) == 0) {
      return(datatable(data.frame(Message = "No data available")))
    }
    
    display_data <- data %>%
      select(center_name, 
             ifelse("location_district" %in% names(data), "location_district", NULL),
             center_type, 
             ifelse("date_visit" %in% names(data), "date_visit", NULL),
             ifelse("surveyor_name" %in% names(data), "surveyor_name", NULL),
             current_enrollment) %>%
      arrange(desc(date_visit)) %>%
      head(10)
    
    datatable(display_data,
              options = list(pageLength = 5),
              rownames = FALSE) %>%
      formatDate('date_visit', method = 'toLocaleDateString')
  })
  
  output$district_summary <- renderDT({
    data <- filtered_data()
    
    if (nrow(data) == 0 || !"location_district" %in% names(data)) {
      return(datatable(data.frame(Message = "No data available")))
    }
    
    summary_data <- data %>%
      group_by(location_district) %>%
      summarize(
        Centers = n(),
        Total_Enrollment = sum(current_enrollment, na.rm = TRUE),
        Avg_Quality = ifelse("quality_score" %in% names(data), round(mean(quality_score, na.rm = TRUE), 2), NA),
        Avg_Caregiver_Ratio = ifelse("caregiver_ratio" %in% names(data), round(mean(caregiver_ratio, na.rm = TRUE), 1), NA)
      ) %>%
      arrange(desc(Centers))
    
    datatable(summary_data,
              options = list(pageLength = 5),
              rownames = FALSE)
  })
  
  output$center_directory <- renderDT({
    data <- filtered_data()
    
    if (nrow(data) == 0) {
      return(datatable(data.frame(Message = "No data available")))
    }
    
    display_data <- data %>%
      select(center_name, 
             ifelse("location_district" %in% names(data), "location_district", NULL),
             center_type, 
             current_enrollment,
             ifelse("quality_score" %in% names(data), "quality_score", NULL),
             ifelse("caregiver_ratio" %in% names(data), "caregiver_ratio", NULL)) %>%
      arrange(desc(current_enrollment))
    
    datatable(display_data,
              options = list(pageLength = 10),
              rownames = FALSE,
              selection = 'single')
  })
  
  # Text outputs
  output$avg_travel_distance <- renderText({
    data <- filtered_data()
    if ("travel_distance" %in% names(data) && nrow(data) > 0) {
      paste(round(mean(data$travel_distance, na.rm = TRUE), 1), "km")
    } else {
      "N/A"
    }
  })
  
  output$delayed_access_rate <- renderText({
    data <- filtered_data()
    if ("delayed_access" %in% names(data) && "current_enrollment" %in% names(data) && nrow(data) > 0) {
      rate <- sum(data$delayed_access, na.rm = TRUE) / sum(data$current_enrollment, na.rm = TRUE) * 100
      paste(round(rate, 1), "%")
    } else {
      "N/A"
    }
  })
  
  output$dropout_rate <- renderText({
    data <- filtered_data()
    if ("dropouts" %in% names(data) && "current_enrollment" %in% names(data) && nrow(data) > 0) {
      rate <- sum(data$dropouts, na.rm = TRUE) / sum(data$current_enrollment, na.rm = TRUE) * 100
      paste(round(rate, 1), "%")
    } else {
      "N/A"
    }
  })
  
  output$capacity_utilization <- renderText({
    data <- filtered_data()
    if ("capacity_utilization" %in% names(data) && nrow(data) > 0) {
      paste(round(mean(data$capacity_utilization, na.rm = TRUE), 1), "%")
    } else {
      "N/A"
    }
  })
  
  output$training_rate <- renderText({
    data <- filtered_data()
    if ("training_received" %in% names(data) && nrow(data) > 0) {
      paste(round(mean(data$training_received == "yes", na.rm = TRUE) * 100, 0), "%")
    } else {
      "N/A"
    }
  })
  
  output$water_sanitation_rate <- renderText({
    data <- filtered_data()
    if ("water_sanitation" %in% names(data) && nrow(data) > 0) {
      paste(round(mean(data$water_sanitation == "yes", na.rm = TRUE) * 100, 0), "%")
    } else {
      "N/A"
    }
  })
  
  output$materials_rate <- renderText({
    data <- filtered_data()
    if ("learning_materials" %in% names(data) && nrow(data) > 0) {
      paste(round(mean(data$learning_materials == "yes", na.rm = TRUE) * 100, 0), "%")
    } else {
      "N/A"
    }
  })
  
  output$parent_involvement_rate <- renderText({
    data <- filtered_data()
    if ("parent_involvement" %in% names(data) && nrow(data) > 0) {
      paste(round(mean(data$parent_involvement == "yes", na.rm = TRUE) * 100, 0), "%")
    } else {
      "N/A"
    }
  })
  
  output$update_time <- renderText({
    format(rv$last_update, "%Y-%m-%d %H:%M")
  })
  
  # Data export functions
  output$export_csv <- downloadHandler(
    filename = function() {
      paste("ecd_data_", Sys.Date(), ".csv", sep = "")
    },
    content = function(file) {
      write.csv(filtered_data(), file, row.names = FALSE)
    }
  )
  
  output$export_excel <- downloadHandler(
    filename = function() {
      paste("ecd_data_", Sys.Date(), ".xlsx", sep = "")
    },
    content = function(file) {
      # Note: Requires writexl package
      # install.packages("writexl")
      writexl::write_xlsx(filtered_data(), file)
    }
  )
  
  # Raw data preview
  output$raw_data_preview <- renderDT({
    datatable(rv$ecd_data,
              options = list(pageLength = 10, scrollX = TRUE),
              rownames = FALSE)
  })
  
  # Data quality check
  observeEvent(input$run_quality_check, {
    data <- rv$ecd_data
    
    if (nrow(data) > 0) {
      quality_report <- data.frame(
        Metric = c("Total Records", "Complete Records", "Missing GPS", 
                   "Missing Enrollment", "Missing Quality Data"),
        Count = c(nrow(data),
                  sum(complete.cases(data[, c("center_name", "center_type", "current_enrollment")])),
                  sum(is.na(data$gps_location__Longitude) | is.na(data$gps_location__Latitude)),
                  sum(is.na(data$current_enrollment)),
                  sum(is.na(data$training_received) | is.na(data$water_sanitation)))
      )
      
      output$data_quality <- renderTable({
        quality_report
      })
    }
  })
  
  # Predictive chart
  output$predictive_chart <- renderPlotly({
    data <- filtered_data()
    
    if (nrow(data) == 0) {
      return(plotly_empty(type = "scatter") %>% 
               layout(title = "No data available"))
    }
    
    # Simulated predictive data based on actual enrollment
    months <- 1:24
    avg_enrollment <- mean(data$current_enrollment, na.rm = TRUE)
    actual <- cumsum(rnorm(24, avg_enrollment/12, avg_enrollment/24))
    forecast <- tail(actual, 12) + cumsum(rnorm(12, avg_enrollment/24, avg_enrollment/48))
    
    plot_ly() %>%
      add_trace(x = 1:12, y = head(actual, 12),
                type = 'scatter', mode = 'lines+markers',
                name = 'Actual (Past Year)',
                line = list(color = colors[2], width = 3)) %>%
      add_trace(x = 13:24, y = forecast,
                type = 'scatter', mode = 'lines+markers',
                name = 'Forecast',
                line = list(color = colors[9], width = 3, dash = 'dash')) %>%
      layout(title = "Enrollment Forecast (12 Months)",
             xaxis = list(title = "Months"),
             yaxis = list(title = "Total Enrollment"),
             plot_bgcolor = '#f9f9f9',
             paper_bgcolor = '#f9f9f9')
  })
  
  # Download report
  output$download_report <- downloadHandler(
    filename = function() {
      paste("ECD_Report_", Sys.Date(), ".pdf", sep = "")
    },
    content = function(file) {
      # Create a simple report
      data <- filtered_data()
      report_text <- paste(
        "ECD Monitoring Report\n",
        "Generated: ", Sys.Date(), "\n",
        "Total Centers: ", nrow(data), "\n",
        "Total Enrollment: ", sum(data$current_enrollment, na.rm = TRUE), "\n",
        "Average Quality Score: ", round(mean(data$quality_score, na.rm = TRUE), 2), "\n",
        "Average Caregiver Ratio: ", round(mean(data$caregiver_ratio, na.rm = TRUE), 1), "\n",
        sep = ""
      )
      
      writeLines(report_text, file)
    }
  )
  
  # Observe events
  observeEvent(input$apply_filters, {
    showNotification("Filters applied successfully!", type = "success")
  })
  
  observeEvent(input$reset_filters, {
    updateSelectInput(session, "district_filter", selected = "All")
    updateSelectInput(session, "center_type_filter", selected = "All")
    updateSliderInput(session, "enrollment_filter", value = c(0, 500))
    showNotification("Filters reset!", type = "info")
  })
}

# Run the application
shinyApp(ui = ui, server = server)

